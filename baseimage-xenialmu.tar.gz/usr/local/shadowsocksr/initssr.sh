#!/bin/bash

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

ssr_folder="/usr/local/shadowsocksr"
config_user_file="${ssr_folder}/user-config.json"
config_user_api_file="${ssr_folder}/userapiconfig.py"

InitSSR(){

  if [ "x$SSR_CFGS_PORT" != "x" ]; then

    ssr_user="dockssr"
    ssr_port=$SSR_CFGS_PORT

    if [ "x$SSR_CFGS_PUB_ADDR" != "x" ]; then
      ssr_server_pub_addr=$SSR_CFGS_PUB_ADDR
    else
      ssr_server_pub_addr=$(wget -qO- -t1 -T2 members.3322.org/dyndns/getip)
    fi
    if [ "x$SSR_CFGS_PASSWORD" != "x" ]; then
      ssr_password=$SSR_CFGS_PASSWORD
    else
      ssr_password="1234567890"
    fi
    if [ "x$SSR_CFGS_METHOD" != "x" ]; then
      ssr_method=$SSR_CFGS_METHOD
    else
      ssr_method="none"
    fi
    if [ "x$SSR_CFGS_PROTOCOL" != "x" ]; then
      ssr_protocol=$SSR_CFGS_PROTOCOL
    else
      ssr_protocol="auth_chain_a"
    fi
    if [ "x$SSR_CFGS_OBFS" != "x" ]; then
      ssr_obfs=$SSR_CFGS_OBFS
    else
      ssr_obfs="http_simple"
    fi
    if [ "x$SSR_CFGS_PROTOPARAM" != "x" ]; then
      ssr_protocol_param=$SSR_CFGS_PROTOPARAM
    else
      ssr_protocol_param=""
    fi
    if [ "x$SSR_CFGS_SPEED_LIMIT_PCONS" != "x" ]; then
      ssr_speed_limit_per_con=$SSR_CFGS_SPEED_LIMIT_PCONS
    else
      ssr_speed_limit_per_con=8
    fi
    if [ "x$SSR_CFGS_SPEED_LIMIT_PUSER" != "x" ]; then
      ssr_speed_limit_per_user=$SSR_CFGS_SPEED_LIMIT_PUSER
    else
      ssr_speed_limit_per_user=0
    fi
    if [ "x$SSR_CFGS_TRANSFER" != "x" ]; then
      ssr_transfer=$SSR_CFGS_TRANSFER
    else
      ssr_transfer="838868"
    fi
    if [ "x$SSR_CFGS_FORBID_PORTS" != "x" ]; then
      ssr_forbid=$SSR_CFGS_FORBID_PORTS
    else
      ssr_forbid=""
    fi

    cd ${ssr_folder}
    cp "${ssr_folder}/config.json" "${config_user_file}"
    cp "${ssr_folder}/mysql.json" "${ssr_folder}/usermysql.json"
    cp "${ssr_folder}/apiconfig.py" "${config_user_api_file}"

    sed -i "s/API_INTERFACE = 'sspanelv2'/API_INTERFACE = 'mudbjson'/" ${config_user_api_file}
    server_pub_addr="127.0.0.1"
    sed -i "s/SERVER_PUB_ADDR = '${server_pub_addr}'/SERVER_PUB_ADDR = '${ssr_server_pub_addr}'/" ${config_user_api_file}
    sed -i 's/ \/\/ only works under multi-user mode//g' "${config_user_file}"

    match_add=$(python mujson_mgr.py -a -u "${ssr_user}" -p "${ssr_port}" -k "${ssr_password}" -m "${ssr_method}" -O "${ssr_protocol}" -G "${ssr_protocol_param}" -o "${ssr_obfs}" -s "${ssr_speed_limit_per_con}" -S "${ssr_speed_limit_per_user}" -t "${ssr_transfer}" -f "${ssr_forbid}"|grep -w "add user info")
  fi
}

InitSSR